(function(newtype, $, undefined )
{		
	var is_ie;
		
	$(document).ready(function()
	{
		is_ie = false;
		
		if($('select').length)
		{		
			$('select').dropdown();
			
			$('input, select, textarea').each(function(i)
			{
				if($(this).attr('type') != 'hidden')
				{
					$(this).attr('tabindex',i+1);
				}
				
				if($(this).hasClass('hidden'))
				{
					$(this).attr('tabindex','').attr('type','hidden');
				}
			});
		}
		
		page_jump();
	});
	
	function page_jump()
	{
		var jump = '<div id="jump"></div>';
		
		$('#wrapper').append(jump);
		
		var e = $('#jump');
		
		$(window).scroll(function() 
		{
			if(window.scrollY >= window.innerHeight/4)
			{
				if(is_ie)
				{
					e.css('display','block');
				} else {
					e.stop().animate({opacity: 1}, 500);
				}
			} else {
				if(is_ie)
				{
					e.css('display','none');
				} else {
					e.stop().animate({opacity: 0}, 500);
				}
			}
		}).scroll();
		
		e.on('click',function()
		{
			$('html, body').animate({scrollTop:0}, 500);
		});
	}
}(window.newtype = window.newtype || {}, jQuery));