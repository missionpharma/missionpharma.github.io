<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*/////////////////////////////////////////
*/// The header scripts helps generate HTML that loads in the JavaScript and CSS in the header 

class Header_Scripts 
{
	/*/////////////////////////////////////////
	*/// Generates the HTML for the CSS
	
	public function get_styles($styles) 
	{
		$links = array('default' => base_url().'css/default.css');
		
		$html = '';
	
		foreach($styles as $style)
		{
			$html .= "\n \t" . '<link href="'.$links[$style].'" rel="stylesheet" />';	
		}
		
		return $html;
	}
	
	/*/////////////////////////////////////////
	*/// Generates the HTML for the JavaScript
	
	public function get_scripts($scripts) 
	{
		$links = array('default'  => base_url().'js/default.js',
					   'dropdown' => base_url().'js/hh_dropdown.min.js',
					   'jquery'   => '//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js');
		
		$html = '';
	
		foreach($scripts as $script)
		{
			$html .= "\n \t" . '<script src="'.$links[$script].'" type="text/javascript"></script>';	
		}
		
		return $html;
	}
}