<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*//////////////////
*/// Form Controller - hanndels all form based actions 

class Form_Control 
{
	private $ci;
	private $fraud;
	
	/*///////////
	*/// Loads CI
	
	public function __construct() 
	{			
		$this->ci =& get_instance();	
		$this->ci->load->entity('Validation');
	}
	
	/*///////////////
	*/// Contest Page
	
	public function contact() 
	{
		$fields = array('name','address','address_2','city','state','zip','email','age','gender');
	
		$this->val = new Validation($this->ci->input->post(),$fields);
		
		$this->val->_str('name');
		$this->val->_str('address');
		$this->val->_str('address_2','',true,true);
		$this->val->_str('city');
		$this->val->_select($this->states(),'state',false,false);
		$this->val->_zip('zip');
		$this->val->_email('email');
		$this->val->_select($this->ages(),'age');
		$this->val->_select($this->genders(),'gender');
		$this->val->_str('message','message',true,false,4500,true);
		
		$valid  = $this->val->valid();
		$values = $this->val->values();
		$errors = $this->val->errors();
		
		if($valid)
		{
			$cleaned = $this->val->clean();
			if(!$this->mail_to($cleaned))
			{
				$this->ci->data['message'] = 'There was an issues sending your contact request, please try once more. If this happens again please use <a href="mailto:info@bravapharmaceuticals.com">info@bravapharmaceuticals.com</a> and contact us directly.';
			} else {
				$this->ci->data['success'] = 'Success! Your message was sent. Someone from our team will be in touch with you shortly.';
			}
		} else 
		if($this->val->submitted())
		{
			$this->ci->data['message'] = 'Please make sure all fields in red are filled with valid data.';
		}
	
		$this->ci->data['values'] = $values;
		$this->ci->data['errors'] = $errors;
	}	
	
	/*/////////////////
	*/// Sends the mail
	
	public function mail_to($data) 
	{
		$subject = 'Brava Pharmaceuticals - Contact Request';
		
		$message = 'A contact request has been sent from bravapharmaceuticals.com'."\n";
		
		if(PROJECT == 'plexion')	
		{
			$message = 'A contact request has been sent from plexion-info.com'."\n";
		}
		
		if(PROJECT == 'keralac')	
		{
			$message = 'A contact request has been sent from keralac-info.com'."\n";
		}
		
		foreach($data as $field => $val)
		{
			$message .= "\n".$field.' - '.$val;
		}
		
		$this->ci->load->library('email');
		
		$this->ci->email->from('noreply@bravapharmaceuticals.com','Noreply');
		$this->ci->email->to('info@bravapharmaceuticals.com');
		
		$this->ci->email->subject($subject);
		$this->ci->email->message($message);
		
		if(!$this->ci->email->send())
		{
			$this->ci->data['message'] = $this->ci->email->print_debugger();
			return false;
		} else {
			return true;
		}
	}
	
	/*//////////////////////
	*/// Returns the genders

	function genders()
	{
		return array('Male','Female');
	}
	
	/*/////////////////////////
	*/// Returns the age groups

	function ages()
	{
		return array('12–17','18–24','25–34','35–44','45–54','55–64','65+');
	}
	
	/*/////////////////////
	*/// Returns the states

	function states()
	{
		return array('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD',
					 'MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD',
					 'TN','TX','UT','VT','VA','WA','WV','WI','WY');
	}
}