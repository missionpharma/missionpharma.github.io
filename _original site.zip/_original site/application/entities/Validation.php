<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*////////////////////
*/// Validation Entite - hanndels the custom validation

class Validation
{
	private $values;
	private $cleaned;
	private $errors;
	private $submitted;
	private $valid;
	
	/*////////////////////////////////
	*/// Inits the validation proccess
	
	public function __construct($post = false,$elements = false,$prefill = false)
	{	
		$this->post   = array(); // Base values
		$this->values = array(); // Form values
		$this->clean  = array(); // Cleaned values for the database
		$this->errors = array(); // Errors from the validation
		$this->valid  = false; // Bool from the validation
		$this->submitted = false; // Bool if the form was submited
		
		if(isset($post['submit']))
		{
			$this->submitted = true; // The post has been submited,
			$this->valid     = true; // assumes the values are valid untill proven otherwise.
		}
		
		if($this->submitted)
		{
			$post = $this->data_mix($post,$elements); // Make sure that all the data for validation is there.
		} else
		if($prefill) {
			$post = $this->data_mix($prefill,$elements); // Adds the prefilled data into the post.
		}
		
		$this->post = $post;
	}
	
	///////////////////////////////
	// Validation Results & Data //
	//////////////////////////////
	
	public function values()
	{
		return $this->values;
	}
	
	public function errors()
	{
		return $this->errors;
	}
	
	public function clean()
	{
		return $this->clean;
	}
	
	public function valid()
	{
		return $this->valid;
	}
	
	public function submitted()
	{
		return $this->submitted;
	}
	
	public function post($data)
	{
		if(isset($this->post[$data]))
		{
			return $this->post[$data];
		}
		
		return false;
	}
	
	///////////////////////////
	// Validation Functions //
	/////////////////////////
		
	/*////////////////////
	*/// String validation - checks to make sure a string is present and that it dose not exeded a length
	
	public function _str($name,$placeholder = '',$db = true,$optional = false,$length = 255,$textarea = false)
	{		
		$str = trim($this->post[$name]);
		$this->errors[$name] = '';
		
		if($textarea)
		{
			$this->values[$name] = $str;
		} else {
			$this->values[$name] = ' value="'.$str.'"';
		}
		
		if(isset($str) && strlen($str) >= 1 && $str != $placeholder)
		{	
			if($str == 'null' || strlen($str) > $length)
			{
				$this->errors[$name] = ' error';
				$this->valid = FALSE;
			} else {
				if($db)
				{
					$this->clean[$name] = $str;
				}
			}
		} else if(!$optional && $this->submitted)
		{
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}
	
	/*///////////////////
	*/// Email validation - Checks to make sure a string contains an email pattern
	
	public function _email($name,$placeholder = '',$optional = false)
	{	
		$email = trim($this->post[$name]);
		$this->errors[$name] = '';
	
		$this->values[$name] = ' value="'.$email.'"';
		
		if(isset($email) && strlen($email) > 1 && $email != $placeholder)
		{		
			if(!(preg_match('/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix', strtolower($email)))?true:false)
			{
				$this->errors[$name] = ' error';
				$this->valid = FALSE;
			} else {
				$this->clean[$name] = $email;
				$this->clean[$name.'_domain'] = $this->get_domain($email);
				$this->clean[$name.'_sanitized'] = $this->sanitized_email($email,$this->clean[$name.'_domain']);
			}
		} else if(!$optional && $this->submitted)
		{
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}
	
	/*/////////////////////////////////
	*/// Grabs the domain from an email
	
	public function get_domain($email)
	{
		$domain = substr(strrchr($email, '@'), 1);
		$parts  = explode('.',$domain);
	
		if(count($parts) != 2)
		{
			$i = count($parts) - 1;
			$domain = $parts[$i];
			
			while($i > 0)
			{
				$i --;
				
				$domain = $parts[$i].'.'.$domain;
					
				if(strlen($parts[$i]) > 3){break;}
			}
		}
	
		return $domain;
	}
	
	/*////////////////////////////////////////////
	*/// Generates a sanitized version of an email
	
	public function sanitized_email($email,$domain)
	{
		$parts = explode('@', $email);
		$user  = $parts[0];
	
		if(substr_count($user,'+') > 0)
		{
			$user_parts = explode('+', $user);
			$user = $user_parts[0];
		}
	
		$user = str_replace('.','',$user);
		
		return $user.'@'.$domain;
	}
	
	/*///////////////////
	*/// Phone validation - Checks to make sure a number matchs a pattern to that of a phone number
	
	public function _phone($name,$optional = false)
	{	
		$phone = trim($this->post[$name]);

		$this->errors[$name] = '';
		$this->values[$name] = ' value="'.$phone.'"';
		
		$phone = str_replace(array('/','\\','[',']','{','}','(',')','-','+','_','=',',','\'','"','#','*','  '),'',$phone);
		$check = preg_replace('/\D/', '', $phone);
		
		if(isset($phone) && $check)
		{		
			$number = $this->_format_phone($phone);
		
			if(!$number)
			{
				$this->errors[$name] = ' error';
				$this->valid = FALSE;
			} else {
				$this->clean[$name] = $number;
			}
		} else if(!$optional && $this->submitted)
		{
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}
	
	function _format_phone($number)
	{
		$format = 
			'/^
		    (?:                                 # Area Code
		        (?:                            
		            \(                          # Open Parentheses
		            (?=\d{3}\))                 # Lookahead.  Only if we have 3 digits and a closing parentheses
		        )?
		        (\d{3})                         # 3 Digit area code
		        (?:
		            (?<=\(\d{3})                # Closing Parentheses.  Lookbehind.
		            \)                          # Only if we have an open parentheses and 3 digits
		        )?
		        [\s.\/-]?                       # Optional Space Delimeter
		    )?
		    (\d{3})                             # 3 Digits
		    [\s\.\/-]?                          # Optional Space Delimeter
		    (\d{4})\s?                          # 4 Digits and an Optional following Space
		    (?:                                 # Extension
		        (?:                             # Lets look for some variation of extension
		            (?:
		                (?:e|x|ex|ext)\.?       # First, abbreviations, with an optional following period
		            |
		                extension               # Now just the whole word
		            )
		            \s?                         # Optionsal Following Space
		        )
		        (?=\d+)                         # This is the Lookahead.  Only accept that previous section IF it\'s followed by some digits.
		        (\d+)                           # Now grab the actual digits (the lookahead doesn\'t grab them)
		    )?                                  # The Extension is Optional
		    $/x';
	
		if(preg_match($format,$number,$parts))
		{
			if(!isset($parts[1]) || strlen($parts[1]) < 1 || !isset($parts[2]) || strlen($parts[2]) < 1 ||
			   !isset($parts[3]) || strlen($parts[3]) < 1)
			{
				return false;
			}
			
			$number = $parts[1].'-'.$parts[2].'-'.$parts[3];
			
			if(isset($parts[4]) && strlen($parts[4]) > 0)
			{
				$number .= ' ext. '.$parts[4];
			}
			
			return $number;
		}
		
		return false;
	}
	
	/*/////////////////
	*/// Zip validation - Checks to make sure a string contains an zipcode pattern
	
	public function _zip($name,$optional = false)
	{	
		$zip = trim($this->post[$name]);
		$this->errors[$name] = '';
		
		$this->values[$name] = ' value="'.$zip.'"';
		
		$zip = str_replace(array('/','\\','[',']','{','}','(',')','-','_','+','=',',','\'','"','#','*','  '),'',$zip);
		
		if(isset($zip) && strlen($zip) > 1)
		{
			if(preg_match('/^\d{5}(?:\-\d{4})?$/i',$zip,$parts))
			{
				if(!isset($parts[0]) || strlen($parts[0]) < 1)
				{
					$this->errors[$name] = ' error';
					$this->valid = FALSE;
				} else {
					$this->clean[$name] = $parts[0];
				}
			} else {
				$this->errors[$name] = ' error';
				$this->valid = FALSE;
			}
		} else if(!$optional && $this->submitted)
		{
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}
	
	/*//////////////////////
	*/// Checkbox validation - makes sure a check is placed where it should be
	
	public function _checkbox($name,$db = true,$optional = false,$prechecked = false)
	{		
		$this->values[$name] = '';
		$this->errors[$name] = '';
		
		$val = $this->post[$name];
		
		if($val && $val != 'n')
		{	
			$this->values[$name] = ' checked="checked"';
			if($db && $this->submitted)
			{
				$this->clean[$name] = 'y';
			}
		} else if($prechecked && !$this->submitted && $val != 'n')
		{
			$this->values[$name] = ' checked="checked"';
		} else if($optional && $this->submitted)
		{
			$this->clean[$name] = 'n';
		} else if(!$optional && $this->submitted)
		{
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}
	
	/*////////////////////
	*/// Number validation - checks to make sure a number is given
	
	public function _number($name,$db = true,$optional = false)
	{
		$val = trim($this->post[$name]);
		$this->errors[$name] = '';
		$this->values[$name] = ' value="'.$val.'"';
		
		if(isset($val) && strlen($val) >= 1)
		{	
			if(!(bool)preg_match( '/^[0-9]+$/', $val))
			{
				$this->errors[$name] = ' error';
				$this->valid = FALSE;
			} else {
				if($db){$this->clean[$name] = $val;}
			}
		} else if(!$optional && $this->submitted)
		{
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}
	
	/*//////////////////
	*/// Date validation - makes sure a valid date is given
	
	public function _date($name,$db = true,$optional = false)
	{
		$val = trim($this->post[$name]);
		$this->errors[$name] = '';
		$this->values[$name] = ' value="'.$val.'"';
		
		if(isset($val) && strlen($val) >= 1)
		{	
			$date = preg_replace("/\D/","",$val);
			
			$y = (int)substr($date, 0, 4);
			$m = (int)substr($date, 4, 2);
			$d = (int)substr($date, 6, 2);
			
			if(!checkdate($m,$d,$y))
			{
				$this->errors[$name] = ' error';
				$this->valid = FALSE;
			} else {
				if($db){$this->clean[$name] = $y.'-'.$m.'-'.$d;}
			}
		} else if(!$optional && $this->submitted)
		{
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}
	
	/*/////////////////
	*/// Age validation - makes sure a valid date is given and the date is atleast x years ago
	
	function _age($y,$m,$d,$age = 18)
	{
		$y = (int)$y; $m = (int)$m; $d = (int)$d;
		
		if(checkdate($m,$d,$y))
		{
			$min = strtotime('midnight -'.$age.'years');
			$dob = strtotime($y.'-'.$m.'-'.$d);
				
			if($min >= $dob){return true;}
		}
		
		return false;
	}
	
	/*////////////////////////////////////
	*/// Dropdown / Select Menu validation - generates the dropdown and checks to see if the given value is with a list
	
	public function _select($data,$name,$optional = false,$select = true)
	{	
		$val = trim($this->post[$name]);
		$html = '<option value="null">None available</option>';
		
		if(is_array($data))
		{
			if($select)
			{
				$html = '<option value="null">Select One</option>';
			} else {
				$html = '';
			}
			
			foreach($data as $option)
			{
				$v = $option;
				$n = $option;
				$selected = '';
				
				if(is_array($option))
				{
					$n = $option['name'];
					
					if(isset($option['val']))
					{
						$v = $option['val'];
					} else {
						$v = (int)$option['id'];
					}
				}
				
				if($v == $val)
				{
					$selected = ' selected="selected"';
					$this->clean[$name] = $v;
				}
				
				$html .= '<option value="'.$v.'"'.$selected.'>'.$n.'</option>';
			}
		}
		
		$this->errors[$name] = '';
		$this->values[$name] = $html;
		
		if(!isset($this->clean[$name]) && !$optional && $this->submitted)
		{	
			$this->errors[$name] = ' error';
			$this->valid = FALSE;
		}
	}

	///////////////////////////
	// Validation Helpers ////
	/////////////////////////	
	
	/*////////////////////////////////////////////
	*/// Combines two arrays and adds false values - used to prevent issues and prefill forms
	
	public function data_mix($a,$b)
	{
		foreach($b as $c){if(!isset($a[$c])){$a[$c] = false;}}
		return $a;
	}
}