
	<div id="content" class="main">
		<div class="content">
		  <h3>FAQ<sub>s</sub></h3>
		
		  <h4 class="mt0">What is Plexion<sup>&reg;</sup>?</h4>
		
		  <p class="e17"><strong>Plexion<sup>&reg;</sup></strong> is a topical treatment used for patients with acne vulgaris,
		  acne rosacea, and seborrheic dermatitis. <strong>Plexion<sup>&reg;</sup></strong> family of products include a
		  cleanser, cloth, cream, and lotion. Why do I have acne? Acne can occur at any age
		  in life, and though there are many factors that can contribute to breakouts, most
		  adult forms of acne include increased sebum production. This over-production of
		  sebum clogs pores, which attracts bacteria. The skin then becomes inflamed causing
		  breakouts.</p>
		
		  <h4>Why do I have rosacea?</h4>
		
		  <p class="e17">The exact cause of rosacea is unknown, however, many
		  researchers&rsquo; theories have evolved over the years. Rosacea has been linked by
		  hereditary and environmental factors. These triggers may lead to increased redness
		  of the face. Dilated blood vessels of the face have often been cited as a factor.
		  As the blood vessels dilate the increased blood near the skin surface makes the
		  skin appear red and flushed. Factors related to blood flow, skin bacteria,
		  microscopic skin mites (Demodex), irritation of follicles, sun damage of the
		  connective tissue under the skin, and an abnormal immune or inflammatory response
		  have been linked to patient&rsquo;s with rosacea.</p>
		
		  <h4>What causes acne? What can I do to clear it up?</h4>
		
		  <p class="e17">Increased sebum production that leads to clogged pores is the main
		  identifier of adult acne. Acne in teens and pre-teens is usually caused by hormones
		  during and after puberty. To treat acne doctors usually prescribe:
		  <br/> <span>&bull; Antibiotic (topical or oral)</span>
		  <br/> <span>&bull; Birth Control (to regulate hormones which can be helpful for women)</span>
		  <br/> <span>&bull; Isotretinoin</span>
		  <br/> <span>&bull; Light therapy</span>
		  <br/> <span>&bull; Chemical peels</span>
		  <br/> <span>&bull; Removal (drainage and extraction)</span></p>
		
		  <h4>What foods cause acne?</h4>
		
		  <p class="e17">There is very little research between the link of food and acne
		  because many dermatologists find inconclusive results. Many do have ongoing
		  theories of certain foods that may cause acne, including processed carbs, refined
		  carbs, and saturated fats. Two separate studies with 47,355 women and found a
		  strong connection between milk and milk product (like cream cheese, sherbet,
		  instant breakfast drinks and cottage cheese) intake and breakouts. Another study,
		  of 4,273 teenaged boys also found an association between milk and acne flare-ups.
		  The conclusion was that the milk contained hormones that caused overactive oil
		  glands which lead to the acne. Journal of American Academy of Dermatology. 2005.
		  Refined Carbs were also tested. Theory suggests that refined carbs cause an insulin
		  spike which spikes sebum production. Archives of Dermatology. 2002. Schulte-Hillen,
		  Sophie. "Can Food Cause Acne?" The Dr.Oz Show. N.p., 30 Jan. 2013. Web. 7 May 2014.
		  .</p>
		
		  <h4>Does chocolate cause acne?</h4>
		
		  <p class="e17">No, there is no direct link to chocolate causing acne. However, a
		  high-sugar/high-fat diet causes increased sebum production.</p>
		
		  <h4>What is the best product to clear up acne?</h4>
		
		  <p class="e17">There is no &ldquo;best product&rdquo; to treat acne. There are many
		  different effective treatments for acne but not every treatment will work for every
		  patient. A dermatologist will have to evaluate a patient and prescribe a medication
		  that they believe will be most beneficial.</p>
		
		  <h4>What do dermatologists recommend for acne and rosacea?</h4>
		
		  <p class="e17">Dermatologists will recommend treatments to clear inflammation such
		  as topical and oral antibiotic medication.</p>
		
		  <h4>Why are acne products so expensive?</h4>
		
		  <p class="e17">Much of the cost of medications in general come from the research
		  and development phase of production, this includes OTC products. However, costs can
		  be reduced dramatically with the Clear Value Savings Card. Pay no more than $20 per
		  script. What is sodium sulfacetamide? How does sodium sulfacetamide stop acne? It
		  is an antibiotic agent. It works by stopping the growth of certain bacteria on the
		  skin that can worsen acne. Sodium sulfacetamide belongs to a class of drugs known
		  as sulfa antibiotics.</p>
		
		  <h4>Should I use a cleanser or a cream to clear up rosacea? Acne?</h4>
		
		  <p class="e17">This is at the discretion of your dermatologist and you.
		  Collectively, you and your physician will find out what works best for you and your
		  at-home beauty regimen. <strong>Plexion<sup>&reg;</sup></strong> is offered in four forms, these include a cleanser,
		  cloth, cream, and lotion. Do acne cleansers have coupons? Are there coupons for
		  cleansers? What is a redemption (should this be savings card?) Prescription
		  name-brand products will most likely have a savings card. Generics do not. A
		  redemption would be a patient taking their saving card to a pharmacy and getting
		  the monetary benefit that the savings card offers.</p>
		
		  <h4>What is the clear value card?</h4>
		
		  <p class="e17">Clear value card is good for all <strong>Plexion<sup>&reg;</sup></strong> products and Keralac. Pay
		  no more than $20 per script with a max benefit of $100. Available for up to 12
		  benefits.</p>
		
		  <h4>What does <strong>Plexion<sup>&reg;</sup></strong> mean?</h4>
		
		  <p class="e17"><strong>Plexion<sup>&reg;</sup></strong> means a solution for patients to control their acne
		  vulgaris, seborrheic dermatitis, and acne rosacea. This product is manufactured by
		  Brava Pharmaceuticals.</p>
		
		  <h4>Is <strong>Plexion<sup>&reg;</sup></strong> available now?</h4>
		
		  <p class="e17">Yes, <strong>Plexion<sup>&reg;</sup></strong> is available now at your local pharmacy. Make sure your
		  doctor e-prescribes you <strong>Plexion<sup>&reg;</sup></strong> or take your prescription with you to the
		  pharmacy.</p>
		
		  <h4>How many products does <strong>Plexion<sup>&reg;</sup></strong> have?</h4>
		
		  <p class="e17"><strong>Plexion<sup>&reg;</sup></strong> has four products:
		  <br/> <span>&bull; <strong>Plexion<sup>&reg;</sup></strong> Cleanser</span>
		  <br/> <span>&bull; <strong>Plexion<sup>&reg;</sup></strong> Cloths</span>
		  <br/> <span>&bull; <strong>Plexion<sup>&reg;</sup></strong> Cream</span>
		  <br/> <span>&bull; <strong>Plexion<sup>&reg;</sup></strong> Lotion</span></p>
		
		  <h4>Can kids under 16 use <strong>Plexion<sup>&reg;</sup></strong>?</h4>
		
		  <p class="e17">This would be under the physician&rsquo;s discretion based on
		  physical examination and medical history. However, safety and effectiveness in
		  children under the age of 12 years have not been established.</p>
		
		  <h4>How do you apply cleansing cloths? Is <strong>Plexion<sup>&reg;</sup></strong> cleansing cloth different than
		  cleansing pads?</h4>
		
		  <p class="e17">Cloths and pads are the same. Moisten the skin and cleansing cloth
		  with water. Work into full lather and massage for 10-20 seconds, rinse thoroughly
		  and pat dry. Discard cloth after use.</p>
		</div>
	</div>
