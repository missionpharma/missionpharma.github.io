
	<div id="content" class="main">
		<div class="content">
			<h2 class="left title s2">Plexion<sup>&reg;</sup> returns!</h2>
			<p class="left e17 mt20">
				The brand long associated with efficacy and value provides topical control for patients with acne vulgaris, acne rosacea, and seborrheic dermatitis. Now getting a prescription of <strong>Plexion<sup>&reg;</sup></strong> has never been easier.
				<br/><br/>
				<strong>Plexion<sup>&reg;</sup></strong> has a family of care products that include <strong>Plexion<sup>&reg;</sup></strong> Cleanser,<br/>
				<strong>Plexion<sup>&reg;</sup></strong> Cleansing Cloths, <strong>Plexion<sup>&reg;</sup></strong> Cream and <strong>Plexion<sup>&reg;</sup></strong> Lotion.
			</p>
			<img class="fix" src="<?php echo $base?>img/bottles.png" alt="Plexion Bottles" />
			<img class="mt30 left" src="<?php echo $base?>img/logos.png" alt="Plexion Logos" />
			<div class="clr"></div>
		</div>
	</div>
