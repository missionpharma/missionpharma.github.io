
	<div id="footer">
		<div class="content shadow">
			<div id="footer_links" class="left">				
				<ul>
					<li><a href="<?php echo $link;?>"><span>Home</span></a></li>
					<li><a href="<?php echo $link;?>rebate"><span>Instant Rebate</span></a></li>
					<li>
						<a href="<?php echo $link;?>products"><span>Products</span></a>
						<a target="_blank" href="http://plexion-info.com/"><span>Plexion<sup>&reg;</sup></span></a>
						<a target="_blank" href="http://keralac-info.com/"><span>Keralac<sup>&reg;</sup></span></a>
					</li>
					<li><a href="<?php echo $link;?>resources"><span>Resources</span></a></li>
					<li class="last"><a href="<?php echo $link;?>contact"><span>Contact</span></a></li>
				</ul>
				<div class="clr"></div>			
			</div>
			<div class="e15 right">
				<p><strong>Brava Pharmaceuticals, LLC</strong><br/>
				2100 West Loop South, Suite 900<br/>
				Houston, TX 77027<br/>
				<strong>1.855.899.4237</strong><br/>
				<a href="mailto:info@bravapharmaceuticals.com">info@bravapharmaceuticals.com</a></p>
			</div>
			<div class="clr"></div>
		</div>
		<div class="pat"></div>
	</div>
	<div id="terms">
		<div class="content">
			<p>&copy; Copyright 2014 Brava Pharmaceuticals, LLC. All Rights Reserved. | <a href="<?php echo $link;?>maps">Site Map</a> | <a href="<?php echo $link;?>privacy">Privacy Policy</a><br/>
			<span>a <strong><a class="newtype" target="_blank" href="http://newty.pe">newtype</a></strong> site</span></p>
		</div>
	</div>
