
	<div id="nav">
		<div class="content">
			<h1 id="logo"><a class="ir" href="<?php echo $link;?>">Brava Pharmaceuticals</a></h1>
			<ul>
				<li><a<?php if($page=='home') echo ' class="active"';?> href="<?php echo $link;?>">Home</a></li>
				<li><a<?php if($page=='rebate') echo ' class="active"';?> href="<?php echo $link;?>rebate">Instant Rebate</a></li>
				<li><a<?php if($page=='products') echo ' class="active"';?> href="<?php echo $link;?>products">Products</a></li>
				<li><a<?php if($page=='resources') echo ' class="active"';?> href="<?php echo $link;?>resources">Resources</a></li>
				<li><a<?php if($page=='contact') echo ' class="active"';?> href="<?php echo $link;?>contact">Contact</a></li>
			</ul>
		</div>
	</div>
