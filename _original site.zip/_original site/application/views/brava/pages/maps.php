
	<div id="content" class="main">
		<div id="spacer"></div>
		<div class="content">
			<h3>Site Map</h3>
			<ul class="e17">
				<li><a href="<?php echo $link;?>"><span>Home</span></a></li>
				<li><a href="<?php echo $link;?>rebate"><span>Instant Rebate</span></a></li>
				<li>
					<a href="<?php echo $link;?>products"><span>Products</span></a><br/>
					&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $link;?>products#plexion"><span>Plexion<sup>&reg;</sup></span></a><br/>
					&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo $link;?>products#keralac"><span>Keralac<sup>&reg;</sup></span></a>
				</li>
				<li><a href="<?php echo $link;?>resources"><span>Resources</span></a></li>
				<li><a href="<?php echo $link;?>contact"><span>Contact</span></a></li>
				<li><a href="<?php echo $link;?>maps"><span>Site Map</span></a></li>
				<li><a href="<?php echo $link;?>privacy"><span>Privacy Policy</span></a></li>
			</ul>
			
			<div class="clr"></div>
		</div>
	</div>







    


