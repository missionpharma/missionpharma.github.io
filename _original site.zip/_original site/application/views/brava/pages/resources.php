
	<div id="content" class="main">
		<div id="spacer"></div>
		<div class="content">
			<h3>Resources</h3>
			<ul class="e17 links">
				<li>American Academy of Dermatology
				<a target="_blank" href="http://www.aad.org/">http://www.aad.org/</a></li>
				<li>North American Clinical Dermatologic Society
				<a target="_blank" href="http://www.nacds.com/">http://www.nacds.com/</a></li>
				
				<li>Dermatology Foundation
				<a target="_blank" href="http://dermatologyfoundation.org/">http://dermatologyfoundation.org/</a></li>
				<li>Society of Dermatology Physician Assistants
				<a target="_blank" href="http://www.dermpa.org">http://www.dermpa.org</a></li>
				    
				<li>Journal of the American Academy of Dermatology
				<a target="_blank" href="http://www.jaad.org/">http://www.jaad.org/</a></li>
				<li>Women's Dermatologic Society
				<a target="_blank" href="http://www.womensderm.org/">http://www.womensderm.org/</a></li>
				    
				<li>Journal of Dermatology for Physician Assistants
				<a target="_blank" href="http://www.jdpa.org/">http://www.jdpa.org/</a></li>
			</ul>
			<div class="clr"></div>
		</div>
	</div>
