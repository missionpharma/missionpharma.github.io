
	<div id="content" class="main">
		<div id="spacer"></div>
		<div class="content">
			<div id="plexion">
				<h3>Products</h3>
				<p class="e17">
					<strong>Plexion<sup>&reg;</sup></strong> returns. The brand long associated with efficacy and value provides topical control for patients with acne vulgaris, acne rosacea, and seborrheic dermatitis. For relief… it’s clearly <strong>Plexion<sup>&reg;</sup></strong>.
					<br/><br/>
					A spectrum of care products that include <strong>Plexion<sup>&reg;</sup></strong> Cleanser, <strong>Plexion<sup>&reg;</sup></strong> Cleansing Cloths, <strong>Plexion<sup>&reg;</sup></strong> Cream and <strong>Plexion<sup>&reg;</sup></strong> Lotion.
				</p>
				<div class="clr"></div>
			</div>
			<div class="clr"></div>
			<a class="ir btn plexion" target="_blank" href="http://plexion-info.com/">Learn about Plexion<sup>&reg;</sup></a>
			<div id="keralac">
				<p class="e17">
					Relief is back! <strong>Keralac<sup>&reg;</sup></strong> (urea 47%) CREAM with a heritage of value and efficacy to smooth relief from dry skin. Now available for the treatment of hyperkeratotic conditions such as dry, rough skin, xerosis, ichthyosis, skin cracks and fissures, dermatitis, eczema, psoriasis, keratosis and calluses.
				</p>
				<div class="clr"></div>
			</div>
			<div class="clr"></div>
			<a class="ir btn keralac" target="_blank" href="http://keralac-info.com/">Learn about Keralac</a>
		</div>
	</div>




