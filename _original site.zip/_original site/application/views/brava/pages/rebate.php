
	<div id="content" class="main">
		<div id="spacer"></div>
		<div class="content">
			<h3>Get an Instant Rebate</h3>
			<p class="e17">
				<img class="right ml45" src="<?php echo $base;?>img/card.jpg" alt="Clear value card" />
				<strong>Plexion<sup>&reg;</sup></strong> returns. The brand long associated with efficacy and value provides topical control for patients with acne vulgaris, acne rosacea, and seborrheic dermatitis. Now, getting a prescription of <strong>Plexion<sup>&reg;</sup></strong> has never been easier. 
				<br/><br/>
				The Clear Value Card allows eligible patients to typically pay no more than $20 per fill with a maximum benefit of $100 per fill.<strong> Plexion<sup>&reg;</sup></strong> or <strong>Keralac<sup>&reg;</sup></strong> (urea 47%) CREAM savings extend up to 12 fills throughout the year. Pay no more than $20 per fill. For relief… it’s clearly <strong>Plexion<sup>&reg;</sup></strong>.
			</p>
			<div class="clr"></div>
			<a class="ir btn mt20" target="_blank" href="https://mprsetrial.mckesson.com/plexion6893/home.html">Get clear value card</a>
		</div>
	</div>

