
	<div id="slider">
		<div class="content">
			<ul id="slides">
				<li>					
					<div class="slide">
						<div class="left">
							<h2 class="title s1">Clear value</h2>
							<p class="brn e17">Now getting a prescription of <strong>Plexion<sup>&reg;</sup></strong> or <strong>Keralac<sup>&reg;</sup></strong> (urea 47%) CREAM has never been easier. The Clear Value Card allows eligible patients to pay no more than $20 per fill with a maximum benefit of $100. Savings extend up to 12 benefits throughout the year.</p>
							<a class="ir btn" target="_blank" href="https://mprsetrial.mckesson.com/plexion6893/home.html">Get clear value card</a>
						</div>
						<div class="right">
							<img src="<?php echo $base;?>img/slider/s1.png" alt="Clear value card" />
						</div>
					</div>
					<div id="s1" class="background"></div>
					<div class="clr"></div>
				</li>
				<li>					
					<div class="slide">
						<div class="left">
							<h2 class="title s2">Plexion<sup>&reg;</sup> returns!</h2>
							<p class="blu e17 f1">The brand long associated with efficacy and value provides topical control for patients with acne vulgaris, acne rosacea, and seborrheic dermatitis. Now getting a prescription of <strong>Plexion<sup>&reg;</sup></strong> has never been easier.</p>
							<a class="ir btn plexion" target="_blank" href="http://plexion-info.com/">Learn about Plexion<sup>&reg;</sup></a>
						</div>
						<div class="right">
							<img src="<?php echo $base;?>img/slider/s2.png" alt="Plexion" />
						</div>
					</div>
					<div id="s2" class="background"></div>
					<div class="clr"></div>
				</li>
				<li>					
					<div class="slide">
						<div class="left">
							<h2 class="title s3">Relief is back!</h2>
							<p class="prp e17 f2"><strong>Keralac<sup>&reg;</sup></strong> (urea 47%) CREAM with a heritage of value and efficacy to smooth relief from dry skin. Now available for the treatment of hyperkeratotic conditions such as dry, rough skin, xerosis, ichthyosis, skin cracks and fissures, dermatitis, eczema, psoriasis, keratosis and calluses.</p>
							<a class="ir btn keralac" target="_blank" href="http://keralac-info.com/">Learn about Keralac</a>
						</div>
						<div class="right">
							<img style="margin-top:30px" src="<?php echo $base;?>img/slider/s3.png" alt="Keralac" />
						</div>
					</div>
					<div id="s3" class="background"></div>
					<div class="clr"></div>
				</li>
			</ul>
			<div class="pat"></div>
		</div>
	</div>
	<div id="content">
		<div class="content">
			<div class="col left">
				<h3>Who is brava pharmaceuticals?</h3>
				<p class="e17"><strong>Brava Pharmaceuticals</strong> is an emerging, privately held Dermatology Company dedicated to delivering exceptional prescription Dermatology products and creating clear value to healthcare providers and their patients. <strong>Brava Pharmaceuticals</strong> through acquisition and development brings to market two highly recognized branded drugs. The two brands, Plexion<sup>&reg;</sup> and Keralac<sup>&reg;</sup>, have significant brand recognition and carry a legacy of success to Dermatologists and their patients with skin conditions such as acne, rosacea, dry, rough skin, and eczema. <strong>Brava Pharmaceuticals</strong> is committed to providing exceptional products and clear value to meet the needs of its customers.</p>
			</div>
			<div class="col right">
				<a href="<?php echo $link;?>resources"><img src="<?php echo $base;?>img/callout.png" alt="Looking  for more  info? Our Resources page will be available soon."/></a>
			</div>
			<div class="clr"></div>
		</div>
	</div>
