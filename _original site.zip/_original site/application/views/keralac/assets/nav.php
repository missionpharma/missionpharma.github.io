
	<div id="nav">
		<div class="content">
			<h1 id="logo"><a class="ir" href="<?php echo $link;?>">Plexion<sup>&reg;</sup> sodium sulfacetamide 9.8% and sulfur 4.8%</a></h1>
			<ul>
				<li><a<?php if($page=='home') echo ' class="active"';?> href="<?php echo $link;?>">Product Info</a></li>
				<li><a<?php if($page=='faq') echo ' class="active"';?> href="<?php echo $link;?>faq">FAQ<sub>s</sub></a></li>
				<li><a<?php if($page=='contact') echo ' class="active"';?> href="<?php echo $link;?>contact">Contact</a></li>
			</ul>
		</div>
	</div>
