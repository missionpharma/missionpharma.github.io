	
	<div id="terms">
		<div class="content">
			<p>&copy; Copyright 2014 <a href="http://bravapharmaceuticals.com/">Brava Pharmaceuticals, LLC.</a> All Rights Reserved. | <a href="http://bravapharmaceuticals.com/privacy">Privacy Policy</a><br/>
			<span>a <strong><a class="newtype" target="_blank" href="http://newty.pe">newtype</a></strong> site</span></p>
		</div>
	</div>
