<!doctype html>  
<html lang="en" >
<head>
	<meta charset="utf-8">
	
	<title>Keralac&reg;</title>
	
	<?php if(isset($desc) && $desc != false && isset($desc['keralac'])):?>
<meta name="description" content="<?php echo $desc['keralac'];?>"/>
	<?php endif; if(isset($keys) && $keys != false && isset($keys['keralac'])):?>
<meta name="keywords" content="<?php echo $keys['keralac'];?>"/>
	<?php endif;?>
	
	<meta name="author" content="http://newty.pe/" />
	<meta name="copyright" content="Copyright &copy; 2014" />
	<meta name="googlebot" content="index, follow" />
	<meta name="robots" content="index, follow" />
	
	<?php echo $style; echo $script;?>

	<script>
		(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		
		ga('create', 'UA-36507831-7', 'bravapharmaceuticals.com');
		ga('send', 'pageview');
	</script>
</head>
<body id="<?php echo $id;?>_pg">
	<div id="wrapper">
		<?php 
			$this->load->view('keralac/assets/nav');
			$this->load->view('keralac/pages/'.$page);
			$this->load->view('keralac/assets/footer');
		?>
	</div>
</body>
</html>