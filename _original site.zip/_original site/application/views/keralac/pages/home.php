
	<div id="content" class="main">
		<div class="content">
			<h2 class="title s3">Relief is back!</h2>
			<p class="left e17 mt20">
				<strong>Keralac<sup>&reg;</sup></strong> (urea 47%) CREAM with a heritage of value and efficacy to smooth relief from dry skin. Now available for the treatment of hyperkeratotic conditions such as dry, rough skin, xerosis, ichthyosis, skin cracks and fissures, dermatitis, eczema, psoriasis, keratosis and calluses.
			</p>
			<img class="fix" src="<?php echo $base?>img/bottles.png" alt="Plexion Bottles" />
			<img class="mt30 clr left" src="<?php echo $base?>img/logos.png" alt="Keralac Logos" />
			<div class="clr"></div>
		</div>
	</div>
