
	<div id="content" class="main">
		<div class="content">
			<h3>Contact Us</h3>			
			<form class="mt20" method="post" action="<?php echo $link;?>contact">
				<p class="e17">For more information about Brava Pharmaceuticals or any of our products, please fill out the form below.</p>
				<?php if(isset($message)) echo '<p class="error e17"><strong>'.$message.'</strong></p>';?>	
				<?php if(isset($success)) echo '<p class="e17">'.$success.'</p>';?>				
				<div class="set left<?php echo $errors['name'];?>">
					<label for="name">Name<span>*</span></label>
					<div class="input"><input type="text"<?php echo $values['name'];?> name="name" /></div>
					<div class="clr"></div>
				</div>
				<div class="set right<?php echo $errors['address'];?>">
					<label for="address">Address 1<span>*</span></label>
					<div class="input"><input type="text"<?php echo $values['address'];?> name="address" /></div>
					<div class="clr"></div>
				</div>
				<div class="clr"></div>
				<div class="set left<?php echo $errors['address_2'];?>">
					<label for="address_2">Address 2</label>
					<div class="input"><input type="text"<?php echo $values['address_2'];?> name="address_2" /></div>
					<div class="clr"></div>
				</div>
				<div class="set right<?php echo $errors['city'];?>">
					<label for="city">City<span>*</span></label>
					<div class="input"><input type="text"<?php echo $values['city'];?> name="city" /></div>
					<div class="clr"></div>
				</div>
				<div class="clr"></div>		
				<div class="set left">
					<div class="set left sm<?php echo $errors['state'];?>">
						<label for="state">State<span>*</span></label>
						<div class="input drop"><select id="state" name="state"><?php echo $values['state'];?></select></div>
						<div class="clr"></div>
					</div>		
					<div class="set right med<?php echo $errors['zip'];?>">
						<label for="zip">Zip Code<span>*</span></label>
						<div class="input"><input type="text"<?php echo $values['zip'];?> name="zip" /></div>
						<div class="clr"></div>
					</div>
				</div>
				<div class="set right<?php echo $errors['email'];?>">
					<label for="email">Email<span>*</span></label>
					<input type="text"<?php echo $values['email'];?> name="email" />
					<div class="clr"></div>
				</div>
				<div class="clr"></div>	
				<div class="set left<?php echo $errors['age'];?>">
					<label for="age">Age Group<span>*</span></label>
					<div class="input drop"><select id="age" name="age"><?php echo $values['age'];?></select></div>
					<div class="clr"></div>
				</div>
				<div class="set right<?php echo $errors['gender'];?>">
					<label for="gender">Gender<span>*</span></label>
					<div class="input drop"><select id="gender" name="gender"><?php echo $values['gender'];?></select></div>
					<div class="clr"></div>
				</div>
				<div class="clr"></div>
				<div class="set full<?php echo $errors['message'];?>">
					<label for="message">Message</label>
					<textarea name="message" rows="4" cols="12"><?php echo $values['message'];?></textarea>
					<div class="clr"></div>
				</div>
				<button class="ir btn submit right" type="submit" name="submit">Submit</button>	
				<p class="left required e14">*Required fields</p>			
				<div class="clr"></div>
			</form>
			<div class="right mt20">
				<p class="e17"><strong>Company Info</strong><br/>
				Brava Pharmaceuticals, LLC<br/>
				2100 West Loop South, Suite 900<br/>
				Houston, TX 77027<br/>
				1.855.899.4237<br/>
				<a href="mailto:info@bravapharmaceuticals.com">info@bravapharmaceuticals.com</a>
				<br/><br/>
				<strong>Career Opportunities</strong><br/>
				For career opportunities, please forward a<br/>
				cover letter and resume to:<br/>
				<a href="mailto:careers@bravapharmaceuticals.com">careers@bravapharmaceuticals.com</a></p>
			</div>
			<div class="clr"></div>
		</div>
	</div>
