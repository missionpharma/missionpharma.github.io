
	<div id="content" class="main">
		<div class="content">
		  <h3>FAQ<sub>s</sub></h3>
				 
		  <h4 class="mt0">What is <strong>Keralac<sup>&reg;</sup></strong>?</h4>
		
		  <p class="e17"><strong>Keralac<sup>&reg;</sup></strong> is a topical cream useful for the treatment of hyperkeratotic
		  conditions such as dry, rough skin, xerosis, ichthyosis, skin cracks and fissures,
		  dermatitis, eczema, psoriasis, keratoses, and calluses.</p>
		
		  <h4>How do I control my dry skin?</h4>
		
		  <p class="e17">There are many ways to help with dry skin. Moisten skin after showering,
		  take warm showers, and cleanse gently.</p>
		
		  <h4>Why do I have dry skin?</h4>
		
		  <p class="e17">Many factors can cause dry skin, here are some more prominent causes:
			  <br/> <span>&bull; Environment (winter weather)</span>
			  <br/> <span>&bull; Steamy Showers</span>
			  <br/> <span>&bull; Moisture-robbing soaps</span></p>
		
		  <h4>What causes dry skin? Anything to help dry cracked skin?</h4>
		
		  <p class="e17">There is no single cause of dry skin. Dry skin causes can be classified
		  as external and internal. External factors are the most common underlying cause and are
		  the easiest to address. External factors include cold temperatures and low humidity,
		  especially during the winter when central heaters are used. Internal factors include
		  overall health, age, genetics, family history, and a personal history of other medical
		  conditions like asthma, allergies, and atopic dermatitis. In particular those with
		  thyroid disease are more prone to developing dry skin.<br />
		  <br />
		  Treatments for dry skin include, hydrocortisone, urea, pramosone, and clobetasol. These
		  medications are intended for a certain severity of dry skin so inform your doctor.</p>
		
		  <h4>What is urea? Can I use urea on my children?</h4>
		
		  <p class="e17">Urea Cream (standard at 40%) is a keratolytic emollient which is a
		  gentle, yet potent, tissue softener for nails and/or skin. Urea is a diamide of
		  carbonic acid.</p>
		
		  <h4>What is the best product to help dry skin?</h4>
		
		  <p class="e17">There is no &ldquo;best product&rdquo; for the treatment of dry skin
		  because everyone has different needs. You and your doctor will come up with a plan to
		  find the best medication for you that fits your needs specifically. What products do
		  dermatologist recommend for dry skin? What do dermatologist prescribe for dry skin?
		  Dermatologists will usually recommend a cream, emollient, or lotion. They can also
		  provide a patient with at-home techniques to relieve dry skin.</p>
		
		  <h4>Why does urea have different strengths?</h4>
		
		  <p class="e17">Urea medications have different strengths depending on the patients need
		  and the severity of the condition.</p>
		
		  <h4>What is <strong>Keralac<sup>&reg;</sup></strong>? How is <strong>Keralac<sup>&reg;</sup></strong> different to other urea creams?</h4>
		
		  <p class="e17"><strong>Keralac<sup>&reg;</sup></strong> cream is intended for dry skin and manufactured by Brava
		  Pharmaceuticals. It contains 47% urea and is in a vehicle consisting of camphor,
		  menthol, and eucalyptus oil.</p>
		
		  <h4>What is the price of <strong>Keralac<sup>&reg;</sup></strong> compared to other urea creams?</h4>
		
		  <p class="e17"><strong>Keralac<sup>&reg;</sup></strong> WAC: $395.00
		  <br/> <span>&bull; Hydro 40 Foam $208.08</span>
		  <br/> <span>&bull; Nutraplus 10% cream $21.39</span>
		  <br/> <span>&bull; KeraFoam 30% $139.01</span>
		  <br/> <span>&bull; Utopic 41% cream $350.00</span></p>
		
		  <h4>What is the clear value card?</h4>
		
		  <p class="e17">Clear value card is good for all Plexion products and <strong>Keralac<sup>&reg;</sup></strong>. Pay no
		  more than $20 per script with a max benefit of $100. Available for up to 12
		  benefits.</p>
		
		  <h4>What does <strong>Keralac<sup>&reg;</sup></strong> mean?</h4>
		
		  <p class="e17"><strong>Keralac<sup>&reg;</sup></strong> cream is a debriding agent. It works by helping the breakdown of
		  dead skin and pus, which helps to loosen and shed hard and scaly skin.</p>
		
		  <h4>Is <strong>Keralac<sup>&reg;</sup></strong> available now?</h4>
		
		  <p class="e17">Yes, <strong>Keralac<sup>&reg;</sup></strong> is available now at your local pharmacy. Make sure your
		  doctor e-prescribes you <strong>Keralac<sup>&reg;</sup></strong> or you take your prescription with you to the
		  pharmacy.</p>
		
		  <h4>How many products does <strong>Keralac<sup>&reg;</sup></strong> have?</h4>
		
		  <p class="e17"><strong>Keralac<sup>&reg;</sup></strong> has one product.</p>
		
		  <h4>Can kids under 12 use <strong>Keralac<sup>&reg;</sup></strong>?</h4>
		
		  <p class="e17">This will be up to the dermatologist discretion.</p>
		
		  <h4>How do you apply <strong>Keralac<sup>&reg;</sup></strong>?</h4>
		
		  <p class="e17">Apply to affected area(s) twice per day as directed by a physician. Rub
		  in until completely absorbed.</p>
		</div>
	</div>
