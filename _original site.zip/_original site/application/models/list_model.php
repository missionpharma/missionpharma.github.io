<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
class List_model extends CI_Model 
{	
	/*//////////////////////
	*/// Returns the genders

	function genders()
	{
		return array('Male','Female');
	}
	
	/*/////////////////////////
	*/// Returns the age groups

	function ages()
	{
		return array('12–17','18–24','25–34','35–44','45–54','55–64','65+');
	}
	
	/*/////////////////////
	*/// Returns the states

	function states()
	{
		return array('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD',
					 'MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD',
					 'TN','TX','UT','VT','VA','WA','WV','WI','WY');
	}
}
?>