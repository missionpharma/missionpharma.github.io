<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*/////////////////////////////////////////
*/// Extented controler for pages
		
class NT_Default extends CI_Controller 
{
	      
	public $data;
	public $header;

	function __construct()  
	{
       	parent::__construct();
       	
       	$brava   = array('home','contact','maps','privacy','products','rebate','resources');
       	$plexion = array('home','contact','faq');
       	$keralac = array('home','contact','faq');
       	
       	$sites = array('brava'=>$brava,'plexion'=>$plexion,'keralac'=>$keralac);
       	
       	if(!isset($sites[PROJECT]) || !in_array($this->router->fetch_class(),$sites[PROJECT]))
       	{
       		redirect(base_url());
       	}
       	
		$this->load->entity('Header_Scripts');
		$this->header = new Header_Scripts();
       			
       	$this->data['base'] = base_url();	
       	$this->data['link'] = base_url();	
    }
}