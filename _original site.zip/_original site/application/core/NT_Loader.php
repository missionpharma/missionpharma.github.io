<?php defined('BASEPATH') OR exit('No direct script access allowed');
class NT_Loader extends CI_Loader 
{
	public function entity($entities = array())
	{
		if(empty($entities)) 
		{ 
			show_error('Unable to load entity. (No entities supplied!)');
		}
		
		if(!is_array($entities))
		{
			$entities = array($entities);
		}	
		
		foreach($entities as $entity)
		{
			$entity_path = APPPATH.'entities/' . str_replace('.php', '', $entity) . '.php';
		
			if(!file_exists($entity_path))
			{
				show_error('Unable to load the requested file: entities/' . $entity . '.php');
			}
			
			include_once($entity_path);
		}
	}
	
	public function entities($entities = array())
	{
		$this->entity($entities);
	}	
}