<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*/////////////////////////////
*/// Controler for the Site Map
	
class Maps extends NT_Default
{
	/*//////////////
	*/// Shared data
	
	public function __construct() 
	{		
        parent::__construct();
						       
		// Page setup
		$this->data['page']   = 'maps';
		$this->data['id']     = 'maps';
		$this->data['title']  = 'Site Map';
		$this->data['style']  = $this->header->get_styles(array('default'));
		$this->data['script'] = $this->header->get_scripts(array('jquery','default'));
	}
	
	/*//////////////
	*/// Main method
	
	public function index()
	{		
		$this->load->view(PROJECT.'/main',$this->data);
	}
}