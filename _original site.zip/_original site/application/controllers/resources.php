<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*///////////////////////////////////
*/// Controler for the Resources page
	
class Resources extends NT_Default
{
	/*//////////////
	*/// Shared data
	
	public function __construct() 
	{		
        parent::__construct();
						       
		// Page setup
		$this->data['page']   = 'resources';
		$this->data['id']     = 'resources';
		$this->data['title']  = 'Resources Page';
		
		$this->data['desc']['brava'] = 'Brava Pharmaceuticals offers additional skin care resources.';
		
		$this->data['style']  = $this->header->get_styles(array('default'));
		$this->data['script'] = $this->header->get_scripts(array('jquery','default'));
	}
	
	/*//////////////
	*/// Main method
	
	public function index()
	{		
		$this->load->view(PROJECT.'/main',$this->data);
	}
}