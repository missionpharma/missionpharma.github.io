<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*//////////////////////////////////
*/// Controler for the Products page
	
class Products extends NT_Default
{
	/*//////////////
	*/// Shared data
	
	public function __construct() 
	{		
        parent::__construct();
						       
		// Page setup
		$this->data['page']   = 'products';
		$this->data['id']     = 'products';
		$this->data['title']  = 'Products Page';
		
		$this->data['desc']['brava'] = 'Brava Pharmaceuticals specializes in two outstanding skin care brands: Plexion&trade; and Keralac&trade;.';
		
		$this->data['style']  = $this->header->get_styles(array('default'));
		$this->data['script'] = $this->header->get_scripts(array('jquery','default'));
	}
	
	/*//////////////
	*/// Main method
	
	public function index()
	{		
		$this->load->view(PROJECT.'/main',$this->data);
	}
}