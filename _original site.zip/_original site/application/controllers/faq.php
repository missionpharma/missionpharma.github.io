<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*//////////////////////////////
*/// Controler for the Home page
	
class Home extends NT_Default
{
	/*//////////////
	*/// Shared data
	
	public function __construct() 
	{		
        parent::__construct();
						       
		// Page setup
		$this->data['page']   = 'faq';
		$this->data['id']     = 'faq';
		$this->data['title']  = 'FAQ Page';
		
		$this->data['desc']['brava'] = 'Brava Pharmaceuticals specializes in two outstanding skin care brands: Plexion&trade; and Keralac&trade;.';
		
		$this->data['desc']['plexion'] = 'Frequently asked questions and answers about Plexion and its family of products.';
		
		$this->data['desc']['keralac'] = 'Frequently asked questions and answers about Keralac.';
		
		$this->data['style']  = $this->header->get_styles(array('default'));
		$this->data['script'] = $this->header->get_scripts(array('jquery','default'));
	}
	
	/*//////////////
	*/// Main method
	
	public function index()
	{		
		$this->load->view(PROJECT.'/main',$this->data);
	}
}