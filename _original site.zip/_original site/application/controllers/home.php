<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*//////////////////////////////
*/// Controler for the Home page
	
class Home extends NT_Default
{
	/*//////////////
	*/// Shared data
	
	public function __construct() 
	{		
        parent::__construct();
						       
		// Page setup
		$this->data['page']   = 'home';
		$this->data['id']     = 'home';
		$this->data['title']  = 'Home Page';
		
		$this->data['desc']['brava'] = 'Brava Pharmaceuticals specializes in two outstanding skin care brands: Plexion&trade; and Keralac&trade;.';
		$this->data['keys']['brava'] = 'Brava, Brava Pharmaceuticals, skincare, skin care, clear skin, acne, rosacea, seborrheic dermatitis, dry skin, psoriasis, eczema, family of products, acne vulgaris, acne rosacea, sulfacetamide, sulfur, non-steroidal formulation, moisturizer for the skin, prescription care acne products, clear value card savings, McKesson, Relay Health, legacy, value, cleansing cloths, convenience, value, prescription dermatology products, hyperkeratotic conditions, fissures, skin cracks, ichthyosis, prescription acne cream, prescription acne lotion, prescription acne cleansing cloths, cleansing pads, treatment for acne';
		
		$this->data['desc']['plexion'] = 'Plexion legacy of efficacy and value returns to provide topical control for patients with acne, rosacea and seborrheic dermatitis.';
		$this->data['keys']['plexion'] = 'Brava, Brava Pharmaceuticals, skincare, skin care, clear skin, acne, rosacea, seborrheic dermatitis, dry skin, psoriasis, eczema, family of products, acne vulgaris, acne rosacea, sulfacetamide, sulfur, non-steroidal formulation, moisturizer for the skin, prescription care acne products, clear value card savings, McKesson, Relay Health, legacy, value, cleansing cloths, convenience, value, prescription dermatology products, hyperkeratotic conditions, fissures, skin cracks, ichthyosis, prescription acne cream, prescription acne lotion, prescription acne cleansing cloths, cleansing pads, treatment for acne';
		
		$this->data['desc']['keralac'] = 'Keralac (urea 47%) CREAM to smooth relief from dry skin. Available in the useful treatment with conditions such as dry, rough skin and eczema.';
		$this->data['keys']['keralac'] = 'Brava, Brava Pharmaceuticals, skincare, skin care, clear skin, acne, rosacea, seborrheic dermatitis, dry skin, psoriasis, eczema, family of products, acne vulgaris, acne rosacea, sulfacetamide, sulfur, non-steroidal formulation, moisturizer for the skin, prescription care acne products, clear value card savings, McKesson, Relay Health, legacy, value, cleansing cloths, convenience, value, prescription dermatology products, hyperkeratotic conditions, fissures, skin cracks, ichthyosis, prescription acne cream, prescription acne lotion, prescription acne cleansing cloths, cleansing pads, treatment for acne';
		
		$this->data['style']  = $this->header->get_styles(array('default'));
		$this->data['script'] = $this->header->get_scripts(array('jquery','default'));
	}
	
	/*//////////////
	*/// Main method
	
	public function index()
	{		
		$this->load->view(PROJECT.'/main',$this->data);
	}
}