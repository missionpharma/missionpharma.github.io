<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/*/////////////////////////////////
*/// Controler for the Contact page
	
class Contact extends NT_Default
{
	/*//////////////
	*/// Shared data
	
	public function __construct() 
	{		
        parent::__construct();
						 
		$this->load->entity('Form_Control');
		
		// Form Helper & Controler
		$this->form = new Form_Control();	
		      
		// Page setup
		$this->data['page']   = 'contact';
		$this->data['id']     = 'contact';
		$this->data['title']  = 'Contact Page';
		
		$this->data['desc']['brava'] = 'Contact Brava Pharmaceuticals for information about Plexion&trade;, Keralac&trade; and career opportunities.';
		$this->data['desc']['plexion'] = 'Contact Brava Pharmaceuticals for information about Plexion and career opportunities.';
		
		$this->data['desc']['keralac'] = 'Contact Brava Pharmaceuticals for information about Keralac and career opportunities.';
		
		$this->data['style']  = $this->header->get_styles(array('default'));
		$this->data['script'] = $this->header->get_scripts(array('jquery','dropdown','default'));
	}
	
	/*//////////////
	*/// Main method
	
	public function index()
	{		
		$this->form->contact();
		$this->load->view(PROJECT.'/main',$this->data);
	}
}