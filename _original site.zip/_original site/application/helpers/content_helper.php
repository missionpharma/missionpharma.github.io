<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*/////////////////////////////////////////
*/// Formats content

function f_con($html,$echo = false)
{	
	$html = auto_link(nl2br($html),'both',true);
	
	if(!$echo){return $html;}
	
	echo $html;
}

/*////////////////////////////////////////
*/// Builds a seires of links via an array

function build_links($links,$base)
{
	$html = '';
	
	foreach($links as $link)
	{
		$html .= '<li><a href="'.$base.$link['id'].'">'.$link['name'].'</a></li>';
	}
	
	return $html;
}

/*/////////////////////////////
*/// Builds a list via an array

function build_list($list,$a = false,$b = false)
{
	$html = '';
	
	foreach($list as $item)
	{
		$extra = '';
		
		if($a)
		{
			$extra = '<span class="blk">'.$item[$a].':</span> ';
		}
		
		$html .= '<li>'.$extra.$item['name'].'</li>';
	}
	
	return $html;
}

/*////////////////////////////////////////
*/// Builds a seires of links via an array

function build_outbound($links)
{
	$html = '';
	
	foreach($links as $link)
	{
		$html .= '<li><a href="'.$link['url'].'" target="_blank">'.$link['name'].'</a></li>';
	}
	
	return $html;
}

/*/////////////////////////////////////////
*/// Cycles through provided data to determ what should be shown

function profile_data($fields,$titles,$profile)
{
	$html = false;
	
	for($i = 0;$i < count($fields); $i++)
	{
		$field = $fields[$i];
		
		if(isset($profile[$field]) && $profile[$field] != null && (!isset($profile[$field.'_show']) || $profile[$field.'_show'] == 'y'))
		{
			if(!$html)
			{
				$html = $titles[$i].' '.$profile[$field];
			} else {
				$html .= '</br>'.$titles[$i].' '.f_con($profile[$field]);
			}
		}
	}
	
	return $html;
}

/*/////////////////////////////////////////
*/// Generates the HTML for the search results

function search_results($results,$key)
{
	$html = '<ul class="results zebra">';
	
	if($results)
	{
		foreach($results as $result)
		{
			$string = string_highlight($result['display_name'],$key);
		
			$html .= '<li><a href="'.base_url().$result['type'].'/profile/'.$result['id'].'"><img class="avatar left" src="'.base_url().'users/thumb/'.$result['logo'].'">'.$string.'</a></li>';
		}
	} else {
		$html .= '<li>Sorry no results found.</li>';
	}
	
	$html .= '</ul>';
	
	return $html;
}

/*/////////////////////////////////////////
*/// Wraps text in a string

function string_highlight($string,$key)
{
	if(strlen($key) === 0){return $string;}
	
	$start = strpos(strtolower($string),strtolower($key));
	
	if($start !== false)
	{
		$replace = substr($string,$start,strlen($key));
		
		$string = str_replace($replace,'<strong>'.$replace.'</strong>',$string);
	}
	
	return $string;
} 

/*/////////////////////////////////////////
*/// pagei nav for search

function search_nav($key,$results_num,$page)
{
	$html = '';
	
	if($results_num > 20)
	{
		if(!$page){$page = 1;}
		$n = $results_num/20 + 1;
		
		$html .= '<p>Pages ';
		
		for($i = 1; $i<$n; $i++)
		{
			if($i > 1)
			{
				$html .= ', ';
			}
			
			if($i == $page)
			{
				$html .= '<a class="active" href="?key='.$key.'">'.$i.'</a>';
			} else {
				$html .= '<a href="?key='.$key.'&page='.$i.'">'.$i.'</a>';
			}
		}
		
		$html .= '</p>';
	}
	
	return $html;
}

/*/////////////////////////////////////////
*/// Lists all the messages
	
function list_messages($messages,$input = true)
{
	$html = '<ul class="results box">';
	
	if($messages)
	{
		foreach($messages as $m)
		{
			if($m['opened'] == 'y')
			{
				$html .= '<li class="opened">';
			} else {
				$html .= '<li>';
			}
			
			$html .= '<img class="avatar left" src="'.base_url().'users/thumb/'.$m['logo'].'">';
			$html .= '<strong>'.$m['display_name'].'</strong> - <a href="'.base_url().'messages/view/'.$m['id'].'">'.$m['title'].'</a><br><span class="meta">Sent on '.date('g:ia, F jS Y',strtotime($m['created_at'])).'</span><div class="clr"></div>';
			
			if($input)
			{
				$html .= '<input class="cb" type="checkbox" name="messages[]" value="'.$m['id'].'"/>';
			}
			
			$html .= '</li>';
		}
	
	} else {
		$html .= '<li>Sorry no messages</li>';
	}
	
	$html .= '</ul>';
	
	return $html;
}

/*/////////////////////////////////////////
*/// page nav for messages

function messages_nav($results_num,$page,$pnavi = false)
{
	$html = '';
	
	if($pnavi)
	{
		$html = '<p class="pnavi"><a class="all" href="#">Select All</a> | <a class="none" href="#">Select None</a> | <a class="read" href="#">Mark Selected as Read</a> | <a class="delete" href="#">Delete Selected</a>';
	}
	
	if($results_num > 10)
	{
		if(!$page){$page = 1;}
		$n = $results_num/10 + 1;
		
		$html .= '<span class="right">Pages ';
		
		for($i = 1; $i<$n; $i++)
		{
			if($i > 1)
			{
				$html .= ', ';
			}
			
			if($page == $i)
			{
				$html .= '<strong>'.$i.'</strong>';
			} else {
				$html .= '<a href="?page='.$i.'">'.$i.'</a>';
			}
		}
		
		$html .= '</span>';
	}
	
	if($pnavi)
	{
		$html .= '</p>';
	}
	
	return $html;
}

/*/////////////////////////////////////////
*/// directory content

function directory_results($data,$nav,$key = false)
{
	$html = '';
	
	if($nav == 'organization/directory'){$nav = 'organization';}
	
	if($data)
	{
		foreach($data as $d)
		{		
			$string = $d['name'];
			
			if($key)
			{
				$string = string_highlight($string,$key);
			}
			
			if(isset($d['count']))
			{
				$string .= ' <strong>('.pluralize($d['count'],'Organization').')</strong>';
			}
			
			if(isset($d['logo']))
			{
				$string = '<img class="avatar left" src="'.base_url().'users/thumb/'.$d['logo'].'">'.$string;
			}
			
			$html .= '<li><a href="'.base_url().$nav.'/'.$d['id'].'">'.$string.'</a></li>';
		}
	} else {
		$html .= '<li>Sorry nothing found.</li>';
	}
	
	return $html;
}

/*/////////////////////////////////////////
*/// basic page page nav

function pnavi($total,$count,$page)
{
	$html = '';
	
	if($total > $count)
	{
		if(!$page){$page = 1;}
		$n = $total/$count + 1;
		
		$html .= '<p class="pnavi">Pages: ';
		
		for($i = 1; $i<$n; $i++)
		{
			if($i > 1)
			{
				$html .= ', ';
			}
			
			if($page == $i)
			{
				$html .= '<strong>'.$i.'</strong>';
			} else {
				$html .= '<a href="?page='.$i.'">'.$i.'</a>';
			}
		}
		
		$html .= '</p>';
	}
	
	return $html;
}

/*/////////////////////////////////////////
*/// Lists all the products
	
function list_products($products)
{
	$html = '<ul class="results zebra">';
	
	if($products)
	{
		foreach($products as $p)
		{
		
			$html .= '<li>'.$p['name'].' <span class="right"><a href="'.base_url().'products/remove/'.$p['id'].'">Remove</a></span></li>';
		}
	
	} else {
		$html .= '<li>No products or services have been added.</li>';
	}
	
	$html .= '</ul>';
	
	return $html;
}

/*/////////////////////////////////////////
*/// Lists all the linked orgs
	
function list_linked_orgs($products)
{
	$html = '<ul class="results zebra">';
	
	if($products)
	{
		foreach($products as $p)
		{
		
			$html .= '<li><strong>Organization: '.$p['name'].'</strong> <span class="right"><a href="'.base_url().'linked_organizations/remove/'.$p['id'].'">Remove</a></span><strong class="right mr10">Link Status: '.$p['status'].'</strong></li>';
		}
	
	} else {
		$html .= '<li>No links have been added.</li>';
	}
	
	$html .= '</ul>';
	
	return $html;
}

/*/////////////////////////////////////////
*/// Ratings	

function ratings($rating,$srv_id = false,$org_id = false)
{
	$count = 5;
	
	$w = $rating*20;
	
	$stars = '';
	
	while($count--)
	{
		$stars .= '<span class="star">&nbsp;</span>';
	}
	
	if($srv_id && $org_id)
	{
		$html = '<div class="rating user" data-srv_id="'.$srv_id.'" data-org_id="'.$org_id.'">'.$stars.'<div class="input"></div><div class="color" style="width:'.$w.'%;"></div><div class="stars"></div></div>';
	} else {
		$html = '<div class="rating">'.$stars.'<div class="color" style="width:'.$w.'%;"></div><div class="stars"></div></div>';
	}
	
	return $html;	
}


/*/////////////////////////////////////////
*/// Truncates a string and adds a hellip to it if the string is truncated
	
function truncate($string, $length = 56)
{
	$string = trim($string);
	
	if(strlen($string) > $length)
	{
		$string = trim(substr($string,0,$length-2)).'…';
	}
	
	return $string;
}

/*///////////////////////////////////////
*/// Determs if text need to be pluralize

function pluralize($count,$text)
{
    return $count.(($count == 1) ? (" $text") : (" ${text}s"));
}

/*////////////////////////////////////
*/// Adds a ordinal suffix to a number

function o_suf($num,$echo = false)
{
    if($num % 100 > 10 && $num %100 < 14)
    {
        $os = 'th';
    } else
    if($num == 0)
    {
        $os = '';
    } else {
        $last = substr($num,-1,1);

        switch($last)
        {
            case "1":
            $os = 'st';
            break;

            case "2":
            $os = 'nd';
            break;

            case "3":
            $os = 'rd';
            break;

            default:
            $os = 'th';
        }
    }
    
	$num .= $os;
	
	if($echo)
	{
		echo $num;
	} else {
		return $num;
	}
}

/*///////////////////
*/// Percent Brackets

function percent_bracket($rank,$count)
{
	$i = 1;
	
	if($count<10){$count = 10;}
		
	while($i < 6)
	{	
		if($rank <= $count - ($count*((10-$i)/10)))
		{
			return ' (Top '.($i*10).'%)';
		}
		
		$i += 0.5;
	}
	
	return '';
}

/*//////////////////
*/// Google Piechart

function piechart($title,$id,$data,$list)
{
	$table = '["data","values"],';
	
	foreach($data as $item)
	{	
		$table .= '["'.$item['name'].'",'.$item['val'].'],';
	}

	$chart = '<div id="'.$id.'" class="pie"></div><script type="text/javascript"> google.load("visualization", "1", {packages:["corechart"]}); google.setOnLoadCallback(function(){var data = google.visualization.arrayToDataTable(['.$table.']);var options={backgroundColor:"#f8f8f8",pieHole:0.33,legend:{position:"none"}}; var chart = new google.visualization.PieChart(document.getElementById("'.$id.'")); chart.draw(data, options);});</script>';
	
	$legend = '';
	
	foreach($list as $name)
	{
		$value = 0;
		
		foreach($data as $item)
		{	
			if($item['name'] == $name){$value = $item['val'];}
		}
		
		$legend .= '<li>'.$name.' (<strong>'.$value.'</strong>)</li>';
	}
	
	$legend = '<ul class="legend">'.$legend.'</ul>';
	
	echo '<div class="dash"></div><div class="chart"><h3 class="e16 clr orj mt20">'.$title.'</h3>'.$chart.$legend.'</div><div class="clr"></div>';
}

/*///////////////////
*/// Google Linechart

function linechart($title,$id,$data,$list)
{
	$table = '["'.$id.'","Votes","Average Rating"],';
	
	foreach($list as $name)
	{
		$value = false;
		$found = false;
		
		if(is_array($name))
		{
			$value = $name['id'];
			$name = $name['name'];
		}
	
		foreach($data as $item)
		{	
			if($item['name'] == $name || $item['name'] == $value)
			{
				$table .= '["'.$name.'",'.$item['val'].','.$item['avg'].'],';
				$found = true;
			}
		}
		
		if(!$found)
		{
			$table .= '["'.$name.'",0,0],';
		}
	}
	
	$chart = '<div id="'.$id.'" class="linechart"></div><script type="text/javascript">google.load("visualization","1",{packages:["corechart"]}); google.setOnLoadCallback(function(){var data = google.visualization.arrayToDataTable(['.$table.']); var options={backgroundColor:"#f8f8f8",legend:{position:"none"}}; var chart = new google.visualization.LineChart(document.getElementById("'.$id.'")); chart.draw(data, options);});</script>';
	
	echo '<div class="dash"></div><div class="chart"><h3 class="e16 clr orj mt20">'.$title.'</h3>'.$chart.'</div><div class="clr"></div>';
}

/*////////////////////
*/// Google Towerchart

function towerchart($title,$id,$data,$list,$start,$end)
{
	$table = '["'.$id.'","Average Ratings","Average Rating"],';
	$found = false;
	
	if(!$end)
	{
		$table = '["'.$id.'","Average Ratings"],';
	}
	
	foreach($list as $name)
	{
		$value = false;
		
		if(is_array($name))
		{
			$value = $name['id'];
			$name = $name['name'];
		}
				
		$sv = 0;
		$ev = 0;
		
		for($i = 0;$i < count($list);$i++)
		{
			if(isset($data['start'][$i]) && ($data['start'][$i]['name'] == $name || $data['start'][$i]['name'] == $value) && isset($data['start'][$i]['avg']))
			{
				$sv = $data['start'][$i]['avg'];
				$found = true;
			}
			
			if(isset($data['end'][$i]) && ($data['end'][$i]['name'] == $name || $data['end'][$i]['name'] == $value) && isset($data['end'][$i]['avg']))
			{
				$ev = $data['end'][$i]['avg'];
				$found = true;
			}
		}
		
		
		if($sv != 0 || $ev != 0)
		{		
			if(!$end)
			{
				$table .= '["'.$name.'",'.$sv.'],';
			} else {
				$table .= '["'.$name.'",'.$sv.','.$ev.'],';
			}
		}		
	}
	
	if(!$found){return;}
		
	$chart = '<div id="'.$id.'" class="towerchart"></div><script type="text/javascript">google.load("visualization","1",{packages:["corechart"]}); google.setOnLoadCallback(function(){var data = google.visualization.arrayToDataTable(['.$table.']); var options={backgroundColor:"#f8f8f8",legend:{position:"none"},vAxis:{viewWindow:{max:6,min:0,mode:"pretty"}}}; var chart = new google.visualization.ColumnChart(document.getElementById("'.$id.'")); chart.draw(data, options);});</script>';
	
	echo '<div class="dash"></div><div class="chart"><h3 class="e16 clr orj mt20">'.$title.'</h3>'.$chart.'</div><div class="clr"></div>';
}
    